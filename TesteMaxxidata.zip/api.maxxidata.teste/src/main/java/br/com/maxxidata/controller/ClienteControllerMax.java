package br.com.maxxidata.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.maxxidata.modelo.ClienteMaxxidata;
import br.com.maxxidata.repository.ClienteMaxRepository;

@RestController
@RequestMapping ("/api/pessoas")
public class ClienteControllerMax {
	
	
	@Autowired
	private ClienteMaxRepository clienteRepository;

	@GetMapping
	public List<ClienteMaxxidata>listar(){
		return clienteRepository.findAll();
	}
	
	@PostMapping
	public ClienteMaxxidata adicionar(@RequestBody ClienteMaxxidata cliente) {
		return clienteRepository.save(cliente);
		
		
	}

}
