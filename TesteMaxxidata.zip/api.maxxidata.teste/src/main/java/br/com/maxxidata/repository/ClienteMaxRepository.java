package br.com.maxxidata.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.maxxidata.modelo.ClienteMaxxidata;

public interface ClienteMaxRepository extends JpaRepository<ClienteMaxxidata, Long>{

}
